from django.apps import AppConfig


class DiabRetinaAppConfig(AppConfig):
    name = 'diab_retina_app'
